<div class="rounded-full my-auto h-full p-2 flex items-center justify-center" id="hijo">
    <img src="{{ asset('src/mapa-del-tesoro.png')}}" alt="Encuentralo" class="w-32 h-28">
</div>