<a {{ $attributes->merge(['class' => 'bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-full border-2 border-black text-xl']) }}>{{ $slot }}</a>
