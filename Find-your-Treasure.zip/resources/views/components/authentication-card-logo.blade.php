<div class="text-center w-2/6 mx-auto h-auto">
    <a href="{{ route('indecs') }}">
        <img src="{{ asset('src/walter-pirata.png') }}" alt="Logo" class="w-32 h-32 mx-auto">
    </a>
</div>