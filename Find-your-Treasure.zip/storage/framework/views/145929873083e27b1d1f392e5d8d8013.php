<div class="text-center w-2/6 mx-auto h-auto">
    <a href="<?php echo e(route('indecs')); ?>">
        <img src="<?php echo e(asset('src/walter-pirata.png')); ?>" alt="Logo" class="w-32 h-32 mx-auto">
    </a>
</div><?php /**PATH C:\xampp\htdocs\Find-your-Treasure\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>