<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div class="relative z-50">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('menu')->html();
} elseif ($_instance->childHasBeenRendered('dOcj7Er')) {
    $componentId = $_instance->getRenderedChildComponentId('dOcj7Er');
    $componentTag = $_instance->getRenderedChildComponentTagName('dOcj7Er');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dOcj7Er');
} else {
    $response = \Livewire\Livewire::mount('menu');
    $html = $response->html();
    $_instance->logRenderedChild('dOcj7Er', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

    <div class="fixed top-0 left-0 w-screen h-screen flex items-center justify-center border-2 border-black">
        <div class="mt-6 flex justify-center text-center relative">
            
            <div class="w-full h-4/5 grid grid-cols-5 gap-2 z-10 bg-amber-950 px-5">
                
                <div class="col-span-5 rounded-xl w-6/12 h-14 mx-auto bg-red-600 flex justify-center items-center mt-3 border-2 border-black">
                    <div class="w-3/12"> 
                        <img src="<?php echo e(asset('src/clavo.png')); ?>" class="w-16 h-16 object-cover mx-auto" alt="Clavo">
                    </div>
                    <div class="w-6/12"> <p class="text-3xl text-gray-100 tracking-widest"> Mi perfil </p> </div>
                    <div class="w-3/12">
                        <img src="<?php echo e(asset('src/clavo.png')); ?>" class="w-16 h-16 object-cover mx-auto" alt="Clavo">
                    </div>
                </div>
                
                
                <div class="col-span-2 row-span-6 bg-red-600 rounded-2xl border-2 border-black">
                    <p class="text-xl text-white tracking-widest">
                        - Se busca -
                    </p>
                    <?php if(Laravel\Fortify\Features::canUpdateProfileInformation()): ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.update-profile-information-form')->html();
} elseif ($_instance->childHasBeenRendered('vaAXAss')) {
    $componentId = $_instance->getRenderedChildComponentId('vaAXAss');
    $componentTag = $_instance->getRenderedChildComponentTagName('vaAXAss');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vaAXAss');
} else {
    $response = \Livewire\Livewire::mount('profile.update-profile-information-form');
    $html = $response->html();
    $_instance->logRenderedChild('vaAXAss', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php endif; ?>
                </div>
                
                <div class="col-span-2 row-span-3 bg-red-600 rounded-2xl hover:bg-red-700">
                    <a href="<?php echo e(route('mobjetosp')); ?>" class="top-0 left-0 border-2 rounded-xl w-full h-full flex flex-col items-center border-black">
                        <img src="<?php echo e(asset('src/mapa.png')); ?>" alt="Icono" class="w-20 h-20 mt-10">
                        <div class="absolute z-10 mt-32">
                            <span class="text-white text-2xl tracking-wider"> Mis Objetos Perdidos </span>
                        </div>
                    </a>
                </div>
                
                
                
                
                <div class="row-span-2 flex items-center justify-center invisible">
                    
                </div>

                
                <div class="row-span-2 bg-red-600 rounded-2xl hover:bg-red-700">
                    <a href="<?php echo e(route('magradecimientos')); ?>" class="top-0 left-0 border-2 rounded-xl w-full h-full flex flex-col items-center border-black">
                        <img src="<?php echo e(asset('src/mapa.png')); ?>" alt="Icono" class="w-20 h-20 mt-10">
                        <div class="absolute z-10 mt-32">
                            <span class="text-white text-2xl tracking-wider"> Mis <br> Agradecimientos </span>
                        </div>
                    </a>
                </div>
                
                <div class="border col-span-2 row-span-3 bg-red-600 rounded-2xl hover:bg-red-700">
                    <a href="<?php echo e(route('mobjetose')); ?>" class="top-0 left-0 border-2 rounded-xl w-full h-full flex flex-col items-center border-black">
                        <img src="<?php echo e(asset('src/pala.png')); ?>" alt="Icono" class="w-20 h-20 mt-10">
                        <div class="absolute z-10 mt-32">
                            <span class="text-white text-2xl tracking-wider"> Mis Objetos Encontrados </span>
                        </div>
                    </a>
                </div>

                
                
                <div class="row-span-2 flex items-center justify-center">
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                            this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                            this.closest(\'form\').submit();']); ?>
                                <?php echo e(__('Abandonar la Cubierta')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </form>
                </div>

                <div class="border col-span-5 invisible"></div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Find-your-Treasure\resources\views/profile/show.blade.php ENDPATH**/ ?>