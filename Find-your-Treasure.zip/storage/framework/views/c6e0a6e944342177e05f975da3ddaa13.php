<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title> Find your Treasure </title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Pirata+One&display=swap" rel="stylesheet">

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

        <!-- Styles -->
        <?php echo \Livewire\Livewire::styles(); ?>

        
        <style>
            body {
                background-image: url(<?php echo e(asset('src/gradient.png')); ?>);
                background-repeat: no-repeat;
                background-size: cover;
                background-attachment: fixed;
            }

            @media (max-width: 640px) {
                body {
                    /* Fondo para resolución md o inferior */
                    background-image: url(<?php echo e(asset('src/FondoCel.png')); ?>);
                }
            }
        </style>
    </head>
    
    <body>
        <div>
            <?php echo $__env->yieldContent('Contenido'); ?>
        </div>
    
        <?php echo $__env->yieldPushContent('modals'); ?>
    
        <?php echo \Livewire\Livewire::scripts(); ?>

    
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>

</html><?php /**PATH C:\xampp\htdocs\Find-your-Treasure\resources\views/layouts/indecs.blade.php ENDPATH**/ ?>