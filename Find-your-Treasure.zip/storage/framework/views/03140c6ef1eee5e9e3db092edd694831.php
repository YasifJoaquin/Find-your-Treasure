<div>
    <div class="absolute inset-0 z-40 w-screen h-screen flex flex-col">
        <div class="relative z-50">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('menu')->html();
} elseif ($_instance->childHasBeenRendered('l3366202091-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3366202091-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3366202091-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3366202091-0');
} else {
    $response = \Livewire\Livewire::mount('menu');
    $html = $response->html();
    $_instance->logRenderedChild('l3366202091-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

        <div class="fixed top-0 left-0 w-screen h-screen flex items-center justify-center mt-6">
            <div class="w-5/6 h-auto mx-auto mt-8 rounded-xl flex flex-col justify-center bg-amber-900 relative">
            <?php if(auth()->check()): ?>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', ['vigia', 'almirante', 'capitan'])): ?>
                    <a href="<?php echo e(route('pregunta')); ?>" class="absolute top-0 right-0 m-4 bg-red-600 text-xl text-white px-4 py-2 rounded-lg border border-black hover:bg-blue-900">Crear Cartel</a>
                <?php endif; ?>
            <?php endif; ?>
            <div class="grid grid-cols-9 h-full text-center gap-4">
                <div class=" invisible"></div>
                <div class=" invisible"></div>
                <div class=" invisible"></div>
                <div class="col-span-3">
                    <div class="border-2 border-black flex justify-between mt-3 items-center bg-red-600 rounded-xl">
                        <img src="<?php echo e(asset('src/clavo.png')); ?>" class="ml-2 w-10 h-10">
                        <h1 class="text-gray-200 text-2xl tracking-widest"> Objetos Perdidos </h1>
                        <img src="<?php echo e(asset('src/clavo.png')); ?>" class="mr-2 w-10 h-10">
                    </div>
                </div>
                <div class=" invisible"></div>
                <div class=" invisible"></div>
                <div class=" invisible"></div>

                <?php if($objetos->count() == 0): ?>
                    <div class="col-span-9 mx-auto mt-40 mb-48">
                        <h1 class="text-center text-5xl text-black">
                            Ahoy marinero, se el primero en publicar tu cartel.!
                        </h1>
                    </div>
                <?php else: ?>
                    <?php $__currentLoopData = $objetos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objeto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-span-3 row-span-6">
                            <div class="w-4/6 h-5/6 mx-auto bg-amber-950">
                                <a href="<?php echo e(route('objeto.show', ['id' => $objeto->id])); ?>">
                                    <div class="h-full pb-20">
                                        <h1 class="tracking-widest text-3xl font-bold w-full pt-5">
                                            - <?php echo e($objeto->estado); ?> -
                                        </h1>
                                        <div class="w-4/5 h-40 mx-auto mt-3 mb-2 bg-gray-300">
                                            <img src="<?php echo e(asset('storage/imagenes/' . $objeto->imagen)); ?>" alt="Imagen del objeto" class="w-full h-full">
                                        </div>

                                        <h2 class="text-2xl tracking-wider font-semibold px-4">
                                            <?php echo e($objeto->objeto); ?>

                                        </h2>
                                        <h3 class="text-lg tracking-wider px-4">
                                            <?php echo e($objeto->ubicacion); ?>

                                        </h3>
                                    </div> 
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-span-9 mx-auto mb-5">
                        <?php echo e($objetos->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Find-your-Treasure\resources\views/livewire/objetos-perdidos.blade.php ENDPATH**/ ?>