<div>
    <div class="flex items-center justify-center space-x-2">
        <?php for($i = 1; $i <= 5; $i++): ?>
            <img
                src="<?php echo e(asset('src/tesoro.png')); ?>"
                alt="Imagen <?php echo e($i); ?>"
                class="cursor-pointer w-12 h-12 <?php echo e($i <= $importanceLevel ? 'opacity-100' : 'opacity-50'); ?>"
                wire:click="setImportanceLevel(<?php echo e($i); ?>)"
            >
        <?php endfor; ?>
    </div>

    
</div>

<?php /**PATH C:\xampp\htdocs\Find-your-Treasure\resources\views/livewire/importancia.blade.php ENDPATH**/ ?>