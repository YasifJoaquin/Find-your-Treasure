<div class="filament-resource-relation-manager">
    <?php echo e(\Filament\Facades\Filament::renderHook('resource.relation-manager.start')); ?>


    <?php echo e($this->table); ?>


    <?php echo e(\Filament\Facades\Filament::renderHook('resource.relation-manager.end')); ?>

</div>
<?php /**PATH C:\xampp\htdocs\Find-your-Treasure\vendor\filament\filament\src\/../resources/views/resources/relation-manager.blade.php ENDPATH**/ ?>