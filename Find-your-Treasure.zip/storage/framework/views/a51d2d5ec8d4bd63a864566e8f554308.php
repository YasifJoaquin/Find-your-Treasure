<h2 <?php echo e($attributes->class(['filament-tables-header-heading text-xl font-bold tracking-tight'])); ?>>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH C:\xampp\htdocs\Find-your-Treasure\vendor\filament\tables\src\/../resources/views/components/header/heading.blade.php ENDPATH**/ ?>