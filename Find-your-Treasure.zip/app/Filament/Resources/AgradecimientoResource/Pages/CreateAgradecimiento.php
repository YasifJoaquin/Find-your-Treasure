<?php

namespace App\Filament\Resources\AgradecimientoResource\Pages;

use App\Filament\Resources\AgradecimientoResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAgradecimiento extends CreateRecord
{
    protected static string $resource = AgradecimientoResource::class;
}
