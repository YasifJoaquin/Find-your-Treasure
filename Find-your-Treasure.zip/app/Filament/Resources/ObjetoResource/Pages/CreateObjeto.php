<?php

namespace App\Filament\Resources\ObjetoResource\Pages;

use App\Filament\Resources\ObjetoResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateObjeto extends CreateRecord
{
    protected static string $resource = ObjetoResource::class;
}
